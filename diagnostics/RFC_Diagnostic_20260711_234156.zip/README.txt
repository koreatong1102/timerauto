RFC Diagnostic Package
======================

이 ZIP은 앱 버그/업그레이드 재현을 위해 만든 진단 패키지입니다.
중요 파일:
- recent_trace.jsonl: 앱 내부 흐름 기록
- app_state.json: 현재 앱/타이머/오버레이 상태
- settings_snapshot.json: 설정 스냅샷
- raw_log_samples/: SpectatorLog 최근 원본 샘플
- spectator_format_detected.json: 로그 포맷 감지 결과
